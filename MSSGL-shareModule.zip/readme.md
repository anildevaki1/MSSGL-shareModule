
///sidenavbar menu info

[{
        icon: "iconname",
            name: 'Name',
            path: 'productmaster',
            params: { action: '', mode: true }
            
                (opt) contnet:[{
                    icon: "iconname",
                    name: 'Name',
                    path: 'productmaster',
                    params: { action: '', mode: true }
            
                            (opt) subContent:[{
                            icon: "iconname",
                            name: 'Name',
                            path: 'productmaster',
                            params: { action: '', mode: true }
                            }]
           }]
}